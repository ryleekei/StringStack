#include <stdio.h> // needed for strstk_print()
#include "strstk.h"


/* This must be called BEFORE calling ANY of the other functions,
 * else their behavior is undefined
 * -- i.e., the program may do anything.
 * PRECONDITION: s is the address of a strstack_t instance.
 * POSTCONDITION: ready for use
 */
void strstk_init(strstk_t *s) {
  s->top = -1;
}

/* Can pop() be safely called on the given stack?
 * I.e., is anything on this stack?
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 * POSTCONDITION: returns nonzero iff there is something on the stack.
 */
int strstk_nonempty(strstk_t *s) {
  //if stack is not empty, return true, else return false
  if (s->top >= 0)
	  return 1;
  else
	  return 0;
}

/* Can push() be safely called on the given stack?
 * I.e., are there fewer than STACK_CAPACITY items on the stack?
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 * POSTCONDITION: returns nonzero iff the stack contains fewer than
 *   STRSTK_CAPACITY elements.
 */
int strstk_nonfull(strstk_t *s) {
	int size = s -> top;
	if(size < STK_CAPACITY-1)
		return 1; 
	else 
		return 0;
}

/* Push a copy of the given character string onto the given stack.
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 *               s has fewer than STACK_CAPACITY items on it.
 *               topush points to a null-terminated character string
 *               than MAX_STRLEN bytes (counting the null).
 * POSTCONDITION: the string pointed to by topush will be returned by the
 *               next call to strstk_pop() if there is no intervening
 *               call to this function.
 */
void strstk_push(strstk_t *s, char *topush) {
	int i = 0;
	s->top = s->top + 1;
	while (i < MAX_STRLEN && ((s->elements[s->top][i] = topush[i]) != '\0'))
		i++;


	/* YOUR CODE HERE.
   * NOTE: because the caller could modify the contents of the arry
   * that "topush" points to after calling this, you have to COPY
   * what the second argument points to into private storage in the
   * given strstk_t instance.
   */
}

/* Remove the most recently push()ed string from this stack and copy it
 * into the array pointed to by the second argument.
 * PRECONDITION: s is the address of an initialized strstk_t instance AND
 *         s is nonempty, i.e., push() has been called more times than pop().
 *         AND result points to a char array of at least MAX_STRLEN bytes.
 * POSTCONDITION: the top element has been copied into the location
 *         pointed to by result and removed from the stack.
 */
void strstk_pop(strstk_t *s, char *result) {
	int i = 0;
	
	while(i < MAX_STRLEN && ((result[i] = s->elements[s->top][i]) != '\0'))
	{
		s->elements[s->top][i] = 0;
		i++;
	}

	s->top = s->top - 1;
  /* YOUR CODE HERE.
   * As with push, because you can't just return a string, this function
   * takes a second argument, which points to the destination for the
   * the string to be popped.
   */
}

/* Print the contents of the stack, one element per line, starting at top.
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 * POSTCONDITION: contents of s have been printed in the order they would be
 *          returned by strstk_pop(), one per line.
 */
void strstk_print(strstk_t *s) {
	int size = s->top;
	printf("==========\n");

	for(int i = size; i >=0; i--)
	{	
		int j = 0;
		while (j < MAX_STRLEN && (s->elements[i][j] != '\0'))
		{
			printf("%c", s->elements[i][j]);
			j++;
		}
		printf("\n");
	}

	printf("==========\n");
  /* Your code here - print the strings stored on the stack.
   * This should not look very different from the intstk version.
   */
}
