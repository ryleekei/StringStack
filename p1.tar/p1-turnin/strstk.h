#ifndef INTSTK_H
#define INTSTK_H

/* Defines the API for the limited-capacity integer stack */

#define STK_CAPACITY 40
#define MAX_STRLEN 96

/* STUDENTS: FILL THIS IN WITH THE DEFINITION OF A str_stack */
typedef struct str_stack {

	char elements[STK_CAPACITY][MAX_STRLEN]; //space for STK_CAPACITY strings of up to MAX_STRLEN
	int top; //keeping track of top of the stack

} strstk_t;

/************* Interface to the stack abstraction *************/
/********* DO NOT CHANGE ANYTHING BELOW THIS LINE *************/

/* This must be called BEFORE calling ANY of the other functions,
 * else their behavior is undefined
 * -- i.e., the program may do anything.
 * PRECONDITION: s is the address of a strstack_t instance.
 * POSTCONDITION: ready for use
 */
void strstk_init(strstk_t *s);

/* Can pop() be safely called on the given stack?
 * I.e., is anything on this stack?
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 * POSTCONDITION: returns nonzero iff there is something on the stack.
 */
int strstk_nonempty(strstk_t *s);

/* Can push() be safely called on the given stack?
 * I.e., are there fewer than STACK_CAPACITY items on the stack?
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 * POSTCONDITION: returns nonzero iff the stack contains fewer than
 *   STRSTK_CAPACITY elements.
 */
int strstk_nonfull(strstk_t *s);

/* Push a copy of the given character string onto the given stack.
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 *               s has fewer than STACK_CAPACITY items on it.
 *               topush points to a null-terminated character string
 *               than MAX_STRLEN bytes (counting the null).
 * POSTCONDITION: the string pointed to by topush will be returned by the
 *               next call to strstk_pop() if there is no intervening
 *               call to this function.
 */
void strstk_push(strstk_t *s, char *topush);

/* Remove the most recently push()ed string from this stack and copy it
 * into the array pointed to by the second argument.
 * PRECONDITION: s is the address of an initialized strstk_t instance AND
 *         s is nonempty, i.e., push() has been called more times than pop().
 *         AND result points to a char array of at least MAX_STRLEN bytes.
 * POSTCONDITION: the top element has been copied into the location
 *         pointed to by result and removed from the stack.
 */
void strstk_pop(strstk_t *s, char *result);

/* Print the contents of the stack, one element per line, starting at top.
 * PRECONDITION: s is the address of an initialized strstk_t instance.
 * POSTCONDITION: contents of s have been printed in the order they would be
 *          returned by strstk_pop(), one per line.
 */
void strstk_print(strstk_t *s); 
#endif
